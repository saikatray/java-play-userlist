import play.Application;
import play.GlobalSettings;

/**
 * Provide initialization code for the digits application.
 * @author Saikat Ray
 */
public class Global extends GlobalSettings {

  /**
   * Initialize the system with some sample contacts.
   * @param app The application.
   */
  public void onStart(Application app) {
	//UserDB.addUser(0, "testUser", "password");  
  }
}

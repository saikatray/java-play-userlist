package models;

import java.util.HashMap;
import java.util.Map;

public class UserDB {
	
	private static Map<String, User> users = new HashMap<String, User>();
	  
	/**
	   * Adds the specified user to the UserInfoDB.
	   * @param name Their name.
	   */
	  public static void addUser(int id, String firstName, String lastName, String email) {
		  users.put(email, new User(id, firstName, lastName, email));
	  }
	  
	  /**
	   * Returns true if the username represents a known user.
	   * @param username The username.
	   * @return True if known user.
	   */
	  public static boolean isUser(String username) {
	    return users.containsKey(username);
	  }

	  /**
	   * Returns the User associated with the username, or null if not found.
	   * @param username The username.
	   * @return The User.
	   */
	  public static User getUser(String username) {
		  System.out.println("UserDB username = "+username);
		  System.out.println("UserDB users = "+users);
		  System.out.println("UserDB users.get = "+users.get(username));
		  //System.out.println("UserDB users..username = "+users.get(username).getUsername());
	    return users.get((username == null) ? "" : username);
	  }

	  /**
	   * Returns true if username and password are valid credentials.
	   * @param username The username. 
	   * @param password The password. 
	   * @return True if username is a valid user username and password is valid for that username.
	   */
	  public static boolean isValid(String username, String password) {
		    System.out.println("UserDB username = "+username+", password = "+password);
	    return ((username != null) 
	            &&
	            (password != null) 
	            &&
	            findUser(username, password));
	  }
	  
	  /**
	     * Generic query helper for entity User with id
	     */
	    public static boolean findUser(String username, String password) {
	    	
	        //List<User> userList = User.find.where().like("email", username).findList();
	       // User currentUser = userList.get(0);
	        //System.out.println("UserDB currentUser  = "+currentUser.getUsername()+", password = "+currentUser.getHashedPassword());
	        //addUser(currentUser.getId(), currentUser.getFirstName(), currentUser.getLastName(), currentUser.getEmail(), currentUser.getUsername(), currentUser.getHashedPassword());
	        //addUser(currentUser.getId(), currentUser.getFirstName(), currentUser.getLastName(), currentUser.getEmail());
	        //System.out.println("pass check = "+password.equals(currentUser.getHashedPassword()));
	        
	        //return password.equals(currentUser.getHashedPassword());
	        return true;
	    }
	    
}

package models;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import com.avaje.ebean.Ebean;
import com.avaje.ebean.Page;
import com.avaje.ebean.RawSql;
import com.avaje.ebean.RawSqlBuilder;

import play.data.format.Formats;
import play.data.validation.Constraints;
import play.db.ebean.Model;

@Entity
public class Message extends Model{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 604547427077400752L;

	@Id
	int id;
	
	@Constraints.Required
	public String message;

	@Formats.DateTime(pattern="yyyy-MM-dd")
	public Date messageDate;
	
	@ManyToOne
	public User user;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Date getMessageDate() {
		return messageDate;
	}
	public void setMessageDate(Date messageDate) {
		this.messageDate = messageDate;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	
	
	/**
     * Generic query helper for entity Computer with id Long
     */
    public static Finder<Integer,Message> find = new Finder<Integer,Message>(Integer.class, Message.class); 
    
    /**
     * Return a page of Memo
     *
     * @param page Page to display
     * @param pageSize Number of Memo per page
     * @param sortBy Date Inserted property used for sorting
     * @param order Sort order (either or asc or desc)
     * @param filter Filter applied on the name column
     */
    public static Page<Message> page(int page, int pageSize, String sortBy, String order, String filter) {
    	System.out.println("Message:: page = "+page+", pageSize = "+pageSize+", sortBy = "+sortBy+", order = "+order+", filter = "+filter);
    	
    	//TODO fetch data by last modified date    	
//    	String sql = "select m.id, u.first_name, u.last_name, u.email, m.message_date \n" + 
//    			"from user u inner join message m \n" + 
//    			"on u.id=m.user_id\n" + 
//    			"group by u.first_name\n" + 
//    			"order by message_date desc;";
//        RawSql rawSql = RawSqlBuilder.parse(sql)
//        		.columnMapping("m.id", "id")
//                .columnMapping("u.first_name", "user.firstName")
//                .columnMapping("u.last_name", "user.lastName")
//                .columnMapping("u.email", "user.email")
//                .columnMapping("m.message_date", "messageDate")
//                .create();
//
//        return Ebean.createQuery(Message.class)
//                .setRawSql(rawSql)
//                .findPagingList(pageSize)
//                .getPage(page);
    	
        return 
            find.where()
                .ilike("message", "%" + filter + "%")
                .orderBy(sortBy + " " + order)
                .fetch("user")
                .findPagingList(pageSize)
                .getPage(page);
    }
	
}

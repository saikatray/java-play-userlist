package controllers;

import java.util.*;
import play.mvc.*;
import play.data.*;
import play.*;
import views.html.*;
import models.*;

import play.data.Form;
import play.mvc.Controller;
import play.mvc.Result;
import play.mvc.Security;
import views.formdata.LoginFormData;

import com.avaje.ebean.Page;


/**
 * Implements the controllers for this application.
 * @author Saikat Ray
 */
public class Application extends Controller {

  /**
   * Provides the Index page.
   * @return The Index page. 
   */
  public static Result index() {
    return ok(Index.render("Home", Secured.isLoggedIn(ctx()), Secured.getUser(ctx())));
  }
  
  /**
   * Provides the Login page (only to unauthenticated users). 
   * @return The Login page. 
   */
  public static Result login() {
    Form<LoginFormData> formData = Form.form(LoginFormData.class);
    return ok(Login.render("Login", Secured.isLoggedIn(ctx()), Secured.getUser(ctx()), formData));
  }

  /**
   * Processes a login form submission from an unauthenticated user. 
   * First we bind the HTTP POST data to an instance of LoginFormData.
   * The binding process will invoke the LoginFormData.validate() method.
   * If errors are found, re-render the page, displaying the error data. 
   * If errors not found, render the page with the good data. 
   * @return The index page with the results of validation. 
   */
  public static Result postLogin() {

    // Get the submitted form data from the request object, and run validation.
    Form<LoginFormData> formData = Form.form(LoginFormData.class).bindFromRequest();

    if (formData.hasErrors()) {
      flash("error", "Login credentials not valid.");
      return badRequest(Login.render("Login", Secured.isLoggedIn(ctx()), Secured.getUser(ctx()), formData));
    }
    else {
      // email/password OK, so now we set the session variable and only go to authenticated pages.
      session().clear();
      
      session("email", formData.get().email);
      session("username", formData.get().email);
      
      System.out.println("Application email  = "+formData.get().email);
      System.out.println("Application session email  = "+session().get("email"));
      System.out.println("Application session username  = "+session().get("username"));
      
      return redirect(routes.Application.profile());
    }
  }
  
  /**
   * Logs out (only for authenticated users) and returns them to the Index page. 
   * @return A redirect to the Index page. 
   */
  @Security.Authenticated(Secured.class)
  public static Result logout() {
    session().clear();
    return redirect(routes.Application.index());
  }
  
  /**
   * Provides the Profile page (only to authenticated users).
   * @return The Profile page. 
   */
  @Security.Authenticated(Secured.class)
  public static Result profile() {
    return ok(Profile.render("Profile", Secured.isLoggedIn(ctx()), Secured.getUser(ctx())));
  }
  
  //**************
  
  /**
   * This result directly redirect to application home.
   */
  public static Result GO_HOME = redirect(
      routes.Application.messageList(0, "message", "asc", "")
  );
  
  /**
   * Handle default path requests, redirect to computers list
   */
//  public static Result index() {
//      return GO_HOME;
//  }

  /**
   * Display the list of users.
   *
   * @param page Current page number (starts from 0)
   * @param sortBy Column to be sorted
   * @param order Sort order (either asc or desc)
   * @param filter Filter applied on computer names
   */
  public static Result userList(int page, String sortBy, String order, String filter) {
      return ok(
          userList.render("userList", Secured.isLoggedIn(ctx()), Secured.getUser(ctx()), 
              User.page(page, 10, sortBy, order, filter),
              sortBy, order, filter
          )
      );
  }
  
  /**
   * Display the list of users.
   *
   * @param page Current page number (starts from 0)
   * @param sortBy Column to be sorted
   * @param order Sort order (either asc or desc)
   * @param filter Filter applied on computer names
   */
  public static Result messageList(int page, String sortBy, String order, String filter) {
      return ok(
          messageList.render("messageList", Secured.isLoggedIn(ctx()), Secured.getUser(ctx()), 
              Message.userList(page, 10, sortBy, order, filter),
              sortBy, order, filter
          )
      );
  }
  
  /**
   * Display the 'edit form' of a existing Computer.
   *
   * @param id Id of the computer to edit
   */
  public static Result userMessageList(Long userId, String sortBy, String order) {
	  Message userMessage = new Message();
	  userMessage.setUser(User.find.byId(userId.toString()));
	  Form<Message> userMessageForm = Form.form(Message.class).fill(userMessage);
	  
	  return ok(
			  userMessageList.render("userMessageList", Secured.isLoggedIn(ctx()), Secured.getUser(ctx()),Message.userMessageList(userId), userMessageForm, sortBy, order
	          )
	      );
  }
  
  /**
   * Handle the 'edit form' submission 
   *
   * @param id Id of the computer to edit
   */
  public static Result saveUserMessage(Long userId) {
      Form<Message> userMessageForm = Form.form(Message.class).bindFromRequest();
      Message newMessage = userMessageForm.get();
      newMessage.setUser(User.find.byId(userId.toString()));
      newMessage.setMessageDate(new Date());
      
      if(userMessageForm.hasErrors()) {
          return badRequest(userMessageList.render("userMessageList", Secured.isLoggedIn(ctx()), Secured.getUser(ctx()),Message.userMessageList(userId), userMessageForm,"messageDate","desc"));
      }
      userMessageForm.get().save();
      flash("success", "User " + userMessageForm.get().user.getFirstName() + " has been updated");
      return GO_HOME;
  }
  
}
package models;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import com.avaje.ebean.Ebean;
import com.avaje.ebean.RawSql;
import com.avaje.ebean.RawSqlBuilder;
import com.avaje.ebean.SqlRow;

import play.data.format.Formats;
import play.data.validation.Constraints;
import play.db.ebean.Model;

/**
 * Message entity managed by Ebean
 * @author Saikat Ray
 */
@Entity
public class Message extends Model{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 604547427077400752L;

	@Id
	int id;
	
	@Constraints.Required
	public String message;

	@Formats.DateTime(pattern="yyyy-MM-dd")
	public Date messageDate;
	
	@ManyToOne
	public User user;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Date getMessageDate() {
		return messageDate;
	}
	public void setMessageDate(Date messageDate) {
		this.messageDate = messageDate;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	
	
	/**
     * Generic query helper for entity Message with id Long
     */
    public static Finder<Integer,Message> find = new Finder<Integer,Message>(Integer.class, Message.class); 
    
    /**
     * Return a list of Users based on last Message received
     *
     * @param sortBy Date Inserted property used for sorting
     * @param order Sort order (either or asc or desc)
     * @param filter Filter applied on the name column
     */
    //public static Page<Message> userList(int page, int pageSize, String sortBy, String order, String filter) {
    public static List<Message> userList(int page, int pageSize, String sortBy, String order, String filter) {
    	System.out.println("Message:: page = "+page+", pageSize = "+pageSize+", sortBy = "+sortBy+", order = "+order+", filter = "+filter);
    	
    	//TODO fetch data by last modified date    	
    	String sql = "select u.id, u.first_name, u.last_name, u.email, m.message_date \n" + 
    			"from user u inner join message m \n" + 
    			"on u.id=m.user_id\n" + 
    			"group by u.first_name\n" + 
    			"order by message_date desc limit 10";
//        RawSql rawSql = RawSqlBuilder.parse(sql)
//        		.columnMapping("u.id", "user.id")
//                .columnMapping("u.first_name", "user.firstName")
//                .columnMapping("u.last_name", "user.lastName")
//                .columnMapping("u.email", "user.email")
//                .columnMapping("m.message_date", "messageDate")
//                .create();
        
        List<SqlRow> userMsgRowList = Ebean.createSqlQuery(sql).findList();
        List<Message> userMsgList = new ArrayList<Message>();
        Iterator<SqlRow> iter = userMsgRowList.iterator();
        while(iter.hasNext()) {
        	SqlRow row =  iter.next();
        	Message message = new Message();
        	
//        	System.out.println("row.getString(\"id\") = "+row.getString("id"));
//        	System.out.println(row.getString("message_date"));
        	
        	message.setUser(User.find.byId(row.getString("id")));
        	SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        	try {
        		message.setMessageDate(format.parse(row.getString("message_date")));
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        	//message.setMessageDate(Calendar.(row.getString("message_date")));
        	
        	userMsgList.add(message);
        }
        
//        System.out.println("total list size = "+userMsgList.size());
//        System.out.println("total list size = "+userMsgList.get(0));
        
        return userMsgList;
    }
    
    /**
     * Return a list of Message for user (to display user's last 20 messages)
     *
     * @param userId
     */
    public static List<Message> userMessageList(Long userId) {
    	System.out.println("id = "+userId);
    	
        return 
            find.where()
                .ilike("user.id", "%"+userId+"%")
                .orderBy("message_date desc").setMaxRows(20)                
                .fetch("user")
                .findList();
    }
	
}

package models;

import javax.persistence.Entity;
import javax.persistence.Id;

import com.avaje.ebean.Page;

import play.data.validation.Constraints;
import play.db.ebean.Model;

/**
 * User entity managed by Ebean
 *  @author Saikat Ray
 */
@Entity
public class User extends Model{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5591903337990516420L;

	@Id
	public int id;
	
	@Constraints.Required
	public String firstName;
	
	@Constraints.Required
	public String lastName;
	
	@Constraints.Required
	public String email;
	
	public User(int id, String firstName, String lastName, String email) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}


	/**
     * Generic query helper for entity User
     */
	public static Model.Finder<String,User> find = new Model.Finder<String,User>(String.class, User.class);
	 
	 /**
     * Return a page of User
     *
     * @param page Page to display
     * @param pageSize Number of users per page
     * @param sortBy Date Inserted property used for sorting
     * @param order Sort order (either or asc or desc)
     * @param filter Filter applied on the name column
     */
    public static Page<User> page(int page, int pageSize, String sortBy, String order, String filter) {
    	System.out.println("User:: page = "+page+", pageSize = "+pageSize+", sortBy = "+sortBy+", order = "+order+", filter = "+filter);
    	
        return 
            find.where()
                .ilike("email", "%" + filter + "%")
                .orderBy(sortBy + " " + order)
                .fetch("user")
                .findPagingList(pageSize)
                .getPage(page);
    }
}
